import InitialDash from "./InitialDash";


function DashboardIndustry() {
  return (
    <>
      <InitialDash></InitialDash>
    </>
  )
}

export default DashboardIndustry;