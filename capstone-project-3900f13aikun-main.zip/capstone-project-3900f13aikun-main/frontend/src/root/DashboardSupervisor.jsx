import InitialDash from "./InitialDash";


function DashboardSupervisor() {
  return (
    <>
      <InitialDash></InitialDash>
    </>
  )
}

export default DashboardSupervisor;