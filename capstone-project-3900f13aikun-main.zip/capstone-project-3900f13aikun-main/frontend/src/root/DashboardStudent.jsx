import InitialDash from "./InitialDash";


function DashboardStudent () {
    return(
        <>
            <InitialDash></InitialDash>
    </>
    )
}

export default DashboardStudent;